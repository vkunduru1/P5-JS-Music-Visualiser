//My program is a music visualizer and what it does is when you click "play" it outputs one of the two instrumentals implementented within the program. 
//The first slider controls the speed of the instrumental and the second slider controls the panning of the instrumental.

var song;
var sliderRate;
var sliderPan;
var button;
var button1; 
var amplitude;
var play;
var sounds = [0,1];

function setup() {
  createCanvas(800, 600);
 sounds[0] = loadSound("hiphop.mp3", makeButton1 );
  sounds[1] = loadSound("dark rap.mp3", makeButton2 );
  sliderSpeed = createSlider(0, 1.5, 1, 0.01);
  sliderPan = createSlider(-1, 1, 1, 0.01);
  amplitude = new p5.Amplitude();

  background(random(255));
  
sounds[0].addCue(5, changeBackground);
sounds[1].addCue(5, changeBackground);

}

function changeBackground() { //background colour
  background(random(255), random(255), random(255), 20);
}





function makeButton1() {//before the button instrumental 1 is clicked it is called play new
    var btn = createButton("instrumental 1"); 
    btn.mousePressed(function(){ 
      playPause(0, btn); 
    }); 

}
function makeButton2() {//before the button instrumental 2 is clicked it is called play new
    var btn = createButton("instrumental 2"); 
    btn.mousePressed(function(){ 
      playPause(1, btn); 
    }); 

}
function playPause(sound, theButton) { //creating the play and pause button
  if (!sounds[sound].isPlaying()) {
    sounds[sound].loop();
    sounds[sound].setVolume(1);
    theButton.html("pause");
  } else {
    sounds[sound].pause();
    theButton.html("play");
    updateBackground();

  }
}

function updateBackground(){//the background changes colour as the instrumental plays.
  for (var i = 0; i < sounds.length; i++){
        background(sounds[i].currentTime() * 10, 0, 255);

  }
  
}

function chooseShape(whichShape) { //switch statement outputting rectangle and ellipse.
  switch(whichShape){
    case 0: 
      return ellipse(diam*1.2, random(0, width), diam-10, diam-10);
       break;
    
    case 1:
      return rect(diam*1.2, random(0, width), diam-10, diam-10);
       break;
    
  }
}

function draw() {//for loop connecting the two slider's speed and panning to the sounds.
  for (var i = 0; i < 1; i++){
    
    // 0
    if (i<1){
    sounds[i].pan(sliderPan.value());
  sounds[i].rate(sliderSpeed.value());
    }else{
      
      //1
  sounds[i].pan(sliderPan.value());
  sounds[i].rate(sliderSpeed.value());
    }
    
  }
  
  background(sounds[0].currentTime() * 10, 0, 255, 2);
  var vol = amplitude.getLevel();
  var diam = map(vol, 0, 0.3, 10, 200);
  fill(0, 0, 0);
  
  if(diam > 10) { //if statement stating that if the diameter is greater than 10 then the fill colour of the two shapes are either 0 or 255.
     fill(random(0,255),random(0,255),random(0,255),20);
   Shapes();
}
}
function Shapes()//object
{
  var vol = amplitude.getLevel();
  var diam = map(vol, 0, 0.3, 10, 200);
  var rectangle =  rect(diam*1.2, random(0, width), diam-10, diam-10);
  var circle =  ellipse(diam*1.2, random(0, width), diam-10, diam-10);
}

