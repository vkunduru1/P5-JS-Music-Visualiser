function changeBackground() {
  background(random(255), random(255), random(255), 20);
}

function duration(dur) {
  this.dur = dur;
  this.loopSong = function() {
    this.dur = 210;
    if (sounds[0] > dur) {
      loopSong;
    } else {
      play;
    }
  }
}

function skipSong() {
  var len = duration();
  var l = random(len);
  sounds[0].skip();
}

function loaded(i) {
  // button = createButton("play new");
  // button.mousePressed(function(){playPause(0, button);});
  // button1 = createButton("play new");
  // button1.mousePressed(function(){playPause(1, button1);});
    var btn = createButton("Play New"); 
    btn.mousePressed(function(){ 
      playPause(i, btn); 
    }); 

}

function playPause(sound, theButton) {
  if (!sounds[sound].isPlaying()) {
    sounds[sound].loop();
    sounds[sound].setVolume(1);
    theButton.html("pause");
  } else {
    sounds[sound].pause();
    theButton.html("play");
  }
}




// Original playPause() function
// function playPause() {
//   if (!sounds[0].isPlaying()) {
//     sounds[0].loop();
//     sounds[0].setVolume(1);
//     button.html("pause");
//   } else {
//     sounds[0].pause();
//     button.html("play");
//   }

//   if (!sounds[1].isPlaying()) {
//     sounds[1].loop();
//     sounds[1].setVolume(1);
//     button.html("pause");
//   } else {
//     sounds[1].pause();
//     button.html("play");
//   }
// }
function chooseShape(whichShape) {
  switch(whichShape){
    case 0: 
      return ellipse(diam*1.2, random(0, width), diam-10, diam-10);
      break;
    case 1:
      return rect(diam*1.2, random(0, width), diam-10, diam-10);
      break;
    
  }
}